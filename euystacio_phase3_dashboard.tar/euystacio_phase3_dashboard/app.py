from flask import Flask, render_template, request, jsonify
import datetime

app = Flask(__name__)

# Example live metrics (would be updated dynamically in real deployment)
metrics = {
    "conflict_reduction": 68,
    "resource_equity": 92,
    "cooperative_index": 85
}

hil_feedback = []

@app.route("/")
def index():
    return render_template("index.html", metrics=metrics, feedback=hil_feedback)

@app.route("/submit_feedback", methods=["POST"])
def submit_feedback():
    data = request.json
    hil_feedback.append({
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "message": data.get("message", "")
    })
    return jsonify({"status": "success", "feedback": hil_feedback})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
