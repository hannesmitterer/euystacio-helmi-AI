# Euystacio Helmi AI – Covenant Bundle

This repository contains the full smart contract suite, deployment scripts, and governance framework for the Euystacio Offshore Sovereign Node.

## Contracts
- **EUSDaoGovernance.sol** → Stewardship Token with contribution-weighted voting
- **KarmaBond.sol** → Virtue-based investment mechanism, secured by invariants
- **TrustlessFundingProtocol.sol** → Tranche-based funding unlocked via SHA256 proofs

## Deployment
See DEPLOYMENT.md for full step-by-step guide.
