const { expect } = require("chai");
describe("TrustlessFundingProtocol", function () {
  it("should release tranche with proof", async function () {
    // placeholder test
  });
});
