const { expect } = require("chai");
describe("KarmaBond", function () {
  it("should allow investment", async function () {
    // placeholder test
  });
});
